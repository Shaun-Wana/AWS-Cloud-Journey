# My Cloud Journey

## 2022 — Starting in Cloud

My formal AWS journey began through the AWS re/Start programme. This introduced me to cloud fundamentals and practical AWS concepts and led to earning the AWS Certified Cloud Practitioner certification.

During the same period, I moved into AWS facilitation at Praesignis. This changed my relationship with cloud technology: I was no longer only learning concepts for myself, but also learning how to explain, demonstrate and troubleshoot them for others.

I also facilitated SQL fundamentals, covering areas such as DDL/DML, joins, grouping, views, stored procedures and transactions.

## 2023 — Expanding Across Cloud Platforms

I expanded into Microsoft Azure and facilitated Azure Fundamentals content. I also completed my Higher National Diploma in Information Technology.

My certification journey grew to include Azure Fundamentals, Azure Administrator and Azure Data Fundamentals.

## Building Deeper AWS Architecture Skills

As my AWS experience developed, I moved beyond foundational cloud concepts into architecture topics such as networking, compute, storage, security, serverless services and solution design.

This progression led to earning the **AWS Certified Solutions Architect – Associate** certification.

## Moving Toward Data Engineering

Through facilitation and practical learning, I gained increasing exposure to AWS data and analytics services including:

- Amazon S3
- AWS Glue
- Amazon Athena
- Amazon Redshift
- Amazon QuickSight
- Amazon EMR / Spark concepts
- AWS Lambda

Combined with SQL, Python fundamentals, data modelling and warehousing concepts, this became the foundation for my move into Data Engineering.

## 2026 — Current Goal

I am currently preparing for the **AWS Certified Data Engineer – Associate (DEA-C01)**.

My goal is not only to earn the certification, but to build practical projects demonstrating that I can apply data engineering concepts on AWS.

**Target: December 2026.**
