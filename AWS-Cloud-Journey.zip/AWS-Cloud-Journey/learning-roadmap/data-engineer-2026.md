# AWS Data Engineer Roadmap — 2026

## Goal

Prepare for the **AWS Certified Data Engineer – Associate (DEA-C01)** while building practical evidence of Data Engineering skills.

Target: **December 2026**

## October — Foundations + GitHub Restart

Focus:
- Refresh Python fundamentals
- Strengthen SQL
- Organise GitHub portfolio
- Review S3 and data lake concepts
- Build small AWS automation exercises

Portfolio target:
- Python + AWS Automation
- SQL Data Engineering exercises

## November — Build Data Pipelines

Focus:
- AWS Glue
- Athena
- Data Catalog
- Parquet
- ETL patterns
- Redshift concepts
- Batch vs streaming
- Security and monitoring

Portfolio target:
- End-to-end AWS ETL pipeline
- Serverless processing project
- Begin capstone

## December — Certification + Capstone

Focus:
- Complete capstone
- Scenario-based DEA-C01 preparation
- Review weak domains
- Practice exams
- Architecture explanation
- Portfolio cleanup

Portfolio target:
- Data Engineering capstone
- Architecture documentation
- Final README updates
- Pin strongest repositories/projects

## Definition of Success

By the end of the roadmap:

- AWS Data Engineer – Associate exam attempted/prepared for
- Multiple original projects documented
- At least one end-to-end AWS data pipeline
- Stronger Python and SQL evidence
- GitHub clearly communicates Cloud → Architecture → Data Engineering progression

The roadmap is intentionally practical: certification study and portfolio development should reinforce each other.
