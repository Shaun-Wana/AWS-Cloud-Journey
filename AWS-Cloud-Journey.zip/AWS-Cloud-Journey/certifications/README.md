# Certifications

My certification path reflects the progression from foundational cloud knowledge into administration, architecture and data.

| Certification | Status |
|---|---|
| AWS Certified Cloud Practitioner | Certified |
| Microsoft Azure Fundamentals (AZ-900) | Certified |
| Microsoft Azure Administrator (AZ-104) | Certified |
| Microsoft Azure Data Fundamentals (DP-900) | Certified |
| AWS Certified Solutions Architect – Associate | Certified |
| AWS Certified Data Engineer – Associate (DEA-C01) | In Progress |

## Why Data Engineering Next?

My work has increasingly exposed me to SQL, cloud data storage, analytics services, data pipelines and AWS data architecture concepts.

DEA-C01 is the next step in bringing these areas together into a focused Data Engineering skill set.

> Certification evidence can be added here later through public credential links or badge images where appropriate.
