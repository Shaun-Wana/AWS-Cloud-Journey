# Data Engineering

This directory tracks my transition from cloud architecture and facilitation into practical Data Engineering.

## Skills Being Developed

- Python for data engineering
- Advanced SQL
- Data ingestion
- ETL / ELT
- Data transformation
- Data lakes
- Data warehousing
- Parquet and columnar storage concepts
- Data cataloguing
- Batch processing
- Streaming concepts
- Data quality
- Monitoring
- Security and access control

## AWS Services

The portfolio will increasingly use:

- Amazon S3
- AWS Glue
- Amazon Athena
- Amazon Redshift
- AWS Lambda
- Amazon CloudWatch
- Amazon QuickSight
- Streaming services where appropriate

## Target Architecture

```text
Source Data
    |
    v
Amazon S3 — Raw Zone
    |
    v
AWS Glue / Python
    |
    v
Amazon S3 — Curated Zone
    |
    v
AWS Glue Data Catalog
    |
    +----------------+
    |                |
    v                v
Athena           Redshift
    |
    v
Analytics / Reporting
```

The architecture will evolve as projects are implemented.
