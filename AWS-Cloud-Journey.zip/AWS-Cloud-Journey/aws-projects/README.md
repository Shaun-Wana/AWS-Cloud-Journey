# AWS Projects

This directory will contain original AWS projects created as part of my continued cloud and Data Engineering development.

## Project Queue

### Python AWS Automation
Automate selected AWS operations using Python and Boto3.

### Serverless Data Processing
Explore event-driven processing with Amazon S3 and AWS Lambda.

### AWS ETL Pipeline
Build a pipeline using Amazon S3, AWS Glue, the Glue Data Catalog and Amazon Athena.

### Streaming Pipeline
Explore streaming data ingestion and processing patterns.

## Portfolio Rule

Projects are listed as **planned** until working code and documentation have been added. Training/client materials, assessment answers, confidential information and proprietary content will not be published here.
